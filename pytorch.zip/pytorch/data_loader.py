from reader import *

def small_norb_reader(args, path):
	def extract_patch(dataset):
		extracted = []
		for img in train_dat:
			img_ = img[0].reshape(96,96,1)
			extracted.append(img_)
			img_ = img[1].reshape(96,96,1)
			extracted.append(img_)					
		return np.array(extracted)
	
	#Training Data
	file_handle = open(getPath('train','dat'))
	train_dat = parseNORBFile(file_handle)
	file_handle = open(getPath('train','cat'))
	train_cat = parseNORBFile(file_handle)

	#Test Data
	file_handle = open(getPath('test','dat'))
	test_dat = parseNORBFile(file_handle)
	file_handle = open(getPath('test','cat'))
	test_cat = parseNORBFile(file_handle)

	trainX = extract_patch(train_dat)
	trainY = np.repeat(train_cat, 2)
	trainY = one_hot(trainY, args.output_dim)

	testX = extract_patch(test_dat)
	testY = np.repeat(test_cat, 2)
	testY = one_hot(testY, args.output_dim)

	if args.is_train:
		X = tf.convert_to_tensor(trainX, dtype=tf.float32) / 255.
		Y = tf.convert_to_tensor(trainY, dtype=tf.float32)
		data_count = len(trainX)
	else:
		X = tf.convert_to_tensor(testX, dtype=tf.float32) / 255.
		Y = tf.convert_to_tensor(testY, dtype=tf.float32)

		data_count = len(testX)		

	input_queue = tf.train.slice_input_producer([X, Y],shuffle=True)
		
	if args.is_train:	
		images = tf.image.resize_images(input_queue[0] ,[48, 48])
		images = tf.random_crop(images, [32, 32, 1])
	else:
		images = tf.image.resize_images(input_queue[0] ,[48, 48])
		images = tf.image.resize_image_with_crop_or_pad(images, 32, 32)

	labels = input_queue[1]

	if args.rotate:
		angle = tf.random_uniform([1], minval=-30, maxval=30, dtype=tf.float32)
		radian = angle * math.pi / 180
		images = tf.contrib.image.rotate(images, radian)

	X, Y = tf.train.batch([images, labels],
						  batch_size=args.batch_size
						  )

	return X, Y, data_count

def data_loader(args): 
	path = os.path.join(args.root_path, args.data)
	images, labels, data_count = small_norb_reader(args, path)
	return images, labels, data_count 