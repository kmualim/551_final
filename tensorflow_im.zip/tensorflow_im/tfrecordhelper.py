from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf


def int64_feature(value):
    """Casts value to a TensorFlow int64 feature list."""
    if not isinstance(value, (tuple, list)):
        value = [value]
    return tf.train.Feature(int64_list=tf.train.Int64List(value=value))


def bytes_feature(value):
    """Casts value to a TensorFlow bytes feature list."""
    return tf.train.Feature(bytes_list=tf.train.BytesList(value=[value]))