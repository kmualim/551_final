import tensorflow as tf
from tensorflow.python.framework import ops
from tensorflow.python.framework import dtypes

from glob import glob

import numpy as np
import os

#from capslayer import CapsLayer
from data_loader import * 

epsilon = 1e-9

class capsule_em():
	def __init__(self, args):

		self.graph_path = args.graph_path

		self.input_width = args.input_width
		self.input_height = args.input_height
		self.input_channel = args.input_channel

		self.output_dim = args.output_dim

		self.epochs = args.epochs
		self.batch_size = args.batch_size
		self.learning_rate = args.learning_rate
		self.momentum = args.momentum

		self.lambda_val = args.lambda_val
		self.m_plus = args.m_plus
		self.m_minus = args.m_minus
		self.reg_scale = args.reg_scale

		self.X, self.Y, self.data_count = data_loader(args)
		self.build_model()
		self.build_loss()

		#summary
		self.img_summary = tf.summary.image("input", self.X, max_outputs=5)
		self.loss_summary = tf.summary.scalar("loss", tf.reduce_mean(self.loss))
		self.rec_img_summary = tf.summary.image("rec_img", self.rec_img, max_outputs=5)
		self.acc_summary = tf.summary.scalar("acc", self.accuracy)

	# input should be tensor with size [batch_size, height, width, channels]
	def kernel_tile(self, input, kernel, stride): 
		shape = input.get_shape()
		tile = np.zeros(shape=[kernel, kernel, input_shape[3], kernel*kernel], dtype=np.float32)

		for i in range(kernel): 
			for j in range(kernel): 
				tile[i,j,:,i*kernel+j]=1.0
		
		tile_filter = tf.constant(tile, dtype=tf.float32)
		kernel_out = tf.nn.depthwise_conv2d(input, tile_filter, strides=[1,stride,stride,1], padding='VALID')
		out_shape = kernel_out.get_shape()
		kernel_out = tf.reshape(kernel_out, shape=[int(out_shape[0]), int(out_shape[1]), int(out_shape[2]), int(out_shape[3]), kernel*kernel])
		kernel_out = tf.transpose(kernel_out, perm=[0,1,2,4,3])

		return kernel_out 

	# input should be a tensor sized as [batch_size, caps_num_out, channel_num]
	def squash_func(self, vec):
		norm_2 = tf.reduce_sum(tf.square(vec), -1, keep_dims=True)
		squashed = norm_2/(tf.sqrt(norm_2 + epsilon)*(1 + norm_2))*vec
		return squashed

	# EM routing 
	def EM_routing(self, votes, activation, out_num, regularizer, tag=False):
		batch_size = int(self.batch_size)
		caps_num = int(self.primaryCaps_num)
		n_channels = int(votes.get_shape()[-1])

		sigma=[]
		miu=[]
		activation_out=[]
		test=[]
		with tf.variable_scope("routing") as scope:
			#8x16 weight matrices in the paper
			#there are 32 weight matrices.
			#Each weight matrix is shared among 32x6x6 capsules
			#shape of this matrix can be changed freely
			beta_votes = tf.get_variable("beta_votes", shape=[1, self.primaryCaps_num, out_num, input.shape[3].value, vec_len], dtype=tf.float32,
									 initializer=tf.contrib.layers.xavier_initializer())

			beta_activation = tf.get_variable("beta_activation", shape=[out_num, input.shape[3].value, vec_len], dtype=tf.float32,
									 initializer=tf.contrib.layers.xavier_initializer())
			votes_in = votes
			activation_in = activation 

			#weight = tf.expand_dims(weight, -1)
			#multiples = [1] + [input.shape[1].value/self.primaryCaps_num, 1, 1, 1, 1]
			#weight = tf.tile(weight, multiples=multiples)
			#weight = tf.reshape(weight, [1, input.shape[1].value, out_num, input.shape[3].value, vec_len])
			#weight = tf.tile(weight, [self.batch_size, 1, 1, 1, 1])
			
			#tile tensors to match dimensions
			#input = tf.tile(input, [1, 1, out_num, 1, 1])

			#u_hat = tf.matmul(weight, input, transpose_a=True)
			#u_hat_stopped = tf.stop_gradient(u_hat, name='stop_gradient')

			#b_IJ = tf.constant(np.zeros([batch_size, ]))
			for routenum in range(routing):
				with tf.variable_scope('iter' + str(routenum)):

					#calculate c_ij
					#c_IJ = tf.nn.softmax(b_IJ, dim=2)

					if routenum == 0: 
						r = tf.constant(np.ones([batch_size, caps_num, num_outputs], dtype-np.float32)/num_outputs)

					#if routenum == routing - 1:
						#calculate s_J
					#	s_J = tf.multiply(c_IJ, u_hat)
					#	s_J = tf.reduce_sum(s_J, axis=1, keep_dims=True)
					#	v_J = self.squash_func(s_J)

					else: 
						s_J = -tf.log(tf.sqrt(sigma))-\
								tf.square((votes_in - miu))/(2*sigma)
						s_J = s_J - \
								(tf.reduce_max(s_J, axis=[2,3], keep_dims=True) - tf.log(10.0))

						p_c = tf.exp(tf.reduce_sum(s_J, axis=3))
						ap = p_x * tf.reshape(activation_out, shape=[batch_size, 1, num_outputs])
						r = ap/(tf.reduce_sum(r, axis=2, keep_dims=True)+epsilon)

					# m steps 
					r = r * activation_in
					r = r/(tf.reduce_sum(r, axis=2, keep_dims=True+epsilon))

					r_sum = tf.reduce_sum(r, axis=1, keep_dims=True)
					r1 = tf.reshape((r / (r_sum + epsilon)), shape=[batch_size, caps_num, num_outputs, 1])
					miu = tf.reduce_sum((votes_in * r1), axis=1, keep_dims=True)
					sigma = tf.reduce_sum(tf.square(votes_in - miu) * r1,
                                     axis=1, keep_dims=True) + epsilon

					if routenum == routing-1:
						r_sum = tf.reshape(r_sum, [batch_size, caps_num_c, 1])
						cost_h = (beta_v + tf.log(tf.sqrt(tf.reshape(sigma,
							shape=[batch_size, num_outputs, n_channels])))) * r_sum

						activation_out = tf.nn.softmax(lambda_val * (beta_a - tf.reduce_sum(cost_h, axis=2)))
					else:
						activation_out = tf.nn.softmax(r_sum)
						#s_J = tf.multiply(c_IJ, u_hat_stopped)
						#s_J = tf.reduce_sum(s_J, axis=1, keep_dims=True)
						#v_J = self.squash_func(s_J)

						#v_J_tiled = tf.tile(v_J, [1, input.shape[1].value, 1, 1, 1])
						#u_produce_v = tf.matmul(u_hat_stopped, v_J_tiled, transpose_a=True)
						#b_IJ += u_produce_v

			return miu, activation_out, test
	# input should be tensor with size as [batch_size, caps_num_i, 16]
	# output of this method is the mean of the Gaussian, activation and sum of probabilities 
	def transform(self, input, c, regularizer, tag=False):
		batch_size = self.batch_size
		caps_num = int(input.shape[1].value)
		mat_transform = tf.reshape(input, shape=[batch_size, caps_num, 1, 4, 4 ])
		weight = tf.get_variable("Weight", shape=[1, caps_num, c, 4,4], dtype=tf.float32,
									 initializer=tf.contrib.layers.xavier_initializer())
		weight = tf.tile(w, [batch_size, 1,1,1,1])
		mat_transform = tf.tile(mat_transform, [1,1,c, 1,1])
		votes = tf.reshape(tf.matmul(mat_transform,weight), [batch_size, caps_num, c, 16])
		return votes

	def build_model(self):
		self.CapsNetwork(self.X, name="capsnet")

		self.trainable_vars = tf.trainable_variables()
		print ("number of parameters: ", count_param(self.trainable_vars))

	#implementation of dynamic routing between capsules
	def CapsNetwork(self, input_image):
		data_size = int(input_image.shape[1].value)

		# initializing weights, bias 
		bias_initializer = tf.truncated_normal_initializer(mean=0.0, stddev=0.01)

		weights_initializer = tf.contrib.layers.l2_regularizer(5e-04)

		# conv1 relu
		with tf.variable_scope('conv1') as scope:
			conv1 = tf.contrib.layers.conv2d(input_image, 256,
											 [9,9], 1, padding="VALID",
											 activation_fn=tf.nn.relu,
											 scope=scope)

			print("conv1 output shape: {}".format(conv1.get_shape()))
			capsule = CapsLayer(self.batch_size)
		
		# primary caps
		with tf.variable_scope('primarycaps') as scope: 
			#pose and activation 
			pose = tf.contrib.layers.conv2d(conv1, num_outputs*(4*4), kernel =[9,9], stride=2, padding="SAME")
			pose = tf.reshape(pose, (self.batch_size, conv1.shape[1].value, conv1.shape[2].value, num_outputs, 4*4))
			activation = tf.contrib.layers.conv2d(conv1, num_outputs, kernel =[9,9], stride =2, activation_fn=tf.nn.sigmoid, padding="SAME")
			activation = tf.reshape(activation,(self.batch_size, conv1.shape[1].value, conv1.shape[2].value, num_outputs, 1 ))
			primarycaps = tf.concat([pose, activation], axis=4)
			primarycaps = tf.reshape(primarycaps, (self.batch_size, conv1.shape[1].value, conv1.shape[2].value, num_outputs, -1))
			print("primary caps output shape: {}".format(primarycaps.get_shape()))

		# conv caps layer 1
		with tf.variable_scope('conv_caps1') as scope: 

			caps2 = kernel_tile(primarycaps, 3,2)
			data_size = int(np.floor((data_size-2)/2))
			caps2 = tf.reshape(caps2, shape=[self.batch_size *data_size *data_size, 3*3*num_outputs, 17])
			caps2_activation = tf.reshape(caps2[:,:,16], shape=[self.batch_size *data_size * data_size, 3*3*num_outputs, 1])
			
			#caps2 = capsule.dm_digitCaps(caps1,
			#						     num_outputs=self.output_dim,
			#						     vec_length=16,
			#						     routing=3,
			#						     name="digitcaps_1")

			with tf.variable_scope('votes') as scope: 
				votes = transform(caps2[:,:,16], num_outputs, weights_initializer, tag=True)
				print("Votes shape: {}".format(votes.get_shape()))
			with tf.variable_scope('routing') as scope: 
				miu, activation, _ = em_routing(votes, activation, num_outputs, weights_initializer)
			D=16 # number of channels in output from caps2
			pose = tf.reshape(miu, shape=[self.batch_size*data_size*data_size, D, 16])
			print("Pose Caps2 shape: {}".format(pose.shape()))
			activation = tf.reshape(activation, shape=[self.batch_size*data_size*data_size, D, 1])
			print("Activation Caps2 shape: {}".format(activation.shape()))

		with tf.variable_scope('class_caps') as scope: 
			with tf.variable_scope('votes') as scope: 
				votes = transform(pose, 5, weights_initializer)
				print("Votes class shape: {}".format(votes.get_shape()))
				# coordinate addition 

				coord_add = np.reshape(coord_add, newshape=[data_size*data_size, 1,1,2])
				coord_add = np.tile(coord_add, [batch_size, D, 5, 1])
				coord_add_new = tf.constant(coord_add, dtype=tf.float32)

				votes = tf.concat([coord_add_new, votes], axis=3)
				print("Votes in class cap: {}".format(votes.get_shape()))

			with tf.variable_scope('routing') as scope: 
				miu, activation, _ = em_routing(votes, activation, num_outputs, weights_initializer)
				print("Class cap activation shape: {}".format(activation.get_shape()))

			caps2=tf.reshape(activation, shape=[self.batch_size, data_size, data_size, 5])
		caps2 = tf.reshape(tf.nn.avg_pool(caps2, ksize=[1, data_size, data_size, 1], strides=[1,1,1,1], padding="VALID"), shape=[self.batch_size, 5])
		print("Caps2 output shape:{}".format(caps2.get_shape()))

		D=16 # number of channels in output from caps2
		pose = tf.nn.avg_pool(tf.reshape(miu, shape=[self.batch_size*data_size*data_size, -1], ksize=[1,data_size,data_size,1], strides=[1,1,1,1], padding ='VALID'))
		pose_out = tf.reshape(pose, shape=[self.batch_size, 5 ,18])
		return caps2, pose_out

	def test_accuracy(logits, labels):
		logits_idx = tf.to_int32(tf.argmax(logits, axis=1))
		logits_idx = tf.reshape(logits_idx, shape=(cfg.batch_size,))
		correct_preds = tf.equal(tf.to_int32(labels), logits_idx)
		accuracy = tf.reduce_sum(tf.cast(correct_preds, tf.float32)) / cfg.batch_size
		return accuracy 

    # cross entropy loss 
    #def cross_entropy(): 

    # spread loss 
    #def spread_loss(): 

    # build baseline 


	def build_loss(self):
		#loss function as decribed in the paper
		max_l = tf.square(tf.maximum(0., self.m_plus - self.v_length))
		max_r = tf.square(tf.maximum(0., self.v_length - self.m_minus))

		T_c = self.Y
		L_c = T_c * max_l + self.lambda_val * (1 - T_c) * max_r

		self.margin_loss = tf.reduce_mean(tf.reduce_sum(L_c, axis=1))

		#calculate reconstruction loss
		origin = tf.reshape(self.X, shape=(self.batch_size, -1))
		squared = tf.square(self.decoded - origin)
		self.reconstruction_err = tf.reduce_mean(squared)

		self.loss = self.margin_loss + self.reg_scale * self.reconstruction_err

		#to check accuracy		
		gt = tf.cast(tf.argmax(self.Y, axis=1), tf.int32)
		pred = self.argmax_idx
		correct_prediction = tf.equal(pred, gt)

		self.accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))


